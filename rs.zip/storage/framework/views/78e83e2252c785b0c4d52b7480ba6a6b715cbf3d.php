
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Edit barang</h1>
    
  </div>
  <div class="container mt-5 mb-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card border-0 shadow rounded">
                <div class="card-body">
                    <form action="/laporan-it/ <?php echo e($datas->id); ?>" method='post'>
                        <?php echo csrf_field(); ?>
                    
                       <?php echo method_field('PUT'); ?>
                        <div class="my-3 p-3 bg-body rounded shadow-sm">
                                <div class="mb-3 row">
                                    <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
                                    <div class="col-sm-10">
                                        <input type="date" class="form-control" name='tanggal'
                                            value="<?php echo e($datas->tanggal); ?>" id="tanggal">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="nama" class="col-sm-2 col-form-label">nama</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control"
                                            name='nama'value="<?php echo e($datas->nama); ?>" id="nama">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="unit" class="col-sm-2 col-form-label">unit</label>
                                    <div class="col-sm-10">
                                            <select class="form-select" name="unit" id="unit" data-placeholder="Pilih Unit">
                                                <option value=""></option>
                                                <option value="Lantai 2"<?php if('Lantai 2'==$datas->unit): ?> selected <?php endif; ?> >Lantai 2</option>
                                                <option value="Lantai 3"<?php if('Lantai 3'==$datas->unit): ?> selected <?php endif; ?>>Lantai 3</option>
                                                <option value="Lantai 4"<?php if('Lantai 4'==$datas->unit): ?> selected <?php endif; ?>>Lantai 4</option>
                                                <option value="Lantai 5"<?php if('Lantai 5'==$datas->unit): ?> selected <?php endif; ?>>Lantai 5</option>
                                                <option value="Lantai 6"<?php if('Lantai 6'==$datas->unit): ?> selected <?php endif; ?>>Lantai 6</option>
                                                <option value="IGD"<?php if('IGD'==$datas->unit): ?> selected <?php endif; ?>>IGD</option>
                                                <option value="Marketing"<?php if('Marketing'==$datas->unit): ?> selected <?php endif; ?>>Marketing</option>
                                                <option value="Keuangan"<?php if('Keuangan'==$datas->unit): ?> selected <?php endif; ?>>Keuangan</option>
                                                <option value="kasir"<?php if('kasir'==$datas->unit): ?> selected <?php endif; ?>>kasir</option>
                                                <option value="Casemix"<?php if('Casemix'==$datas->unit): ?> selected <?php endif; ?>>Casemix</option>
                                                <option value="Poli Urologi"<?php if('Poli Urologi'==$datas->unit): ?> selected <?php endif; ?>>Poli Urologi</option>
                                                <option value="Poli Paru"<?php if('Poli Paru'==$datas->unit): ?> selected <?php endif; ?>>Poli Paru</option>
                                                <option value="Poli Orthopedhi"<?php if('Poli Orthopedhi'==$datas->unit): ?> selected <?php endif; ?>>Poli Orthopedhi</option>
                                                <option value="Poli Mata"<?php if('Poli Mata'==$datas->unit): ?> selected <?php endif; ?>>Poli Mata</option>
                                                <option value="Poli Gigi"<?php if('Poli Gigi'==$datas->unit): ?> selected <?php endif; ?>>Poli Gigi</option>
                                                <option value="Poli Bedah Mulut"<?php if('Poli Bedah Mulut'==$datas->unit): ?> selected <?php endif; ?>>Poli Bedah Mulut</option>
                                                <option value="Poli Jantung"<?php if('Poli Jantung'==$datas->unit): ?> selected <?php endif; ?>>Poli Jantung</option>
                                                <option value="Poli Saraf"<?php if('Poli Saraf'==$datas->unit): ?> selected <?php endif; ?>>Poli Saraf</option>
                                                <option value="Poli Kulit"<?php if('Poli Kulit'==$datas->unit): ?> selected <?php endif; ?>>Poli Kulit</option>
                                                <option value="Poli Bedah Plastik"<?php if('Poli Bedah Plastik'==$datas->unit): ?> selected <?php endif; ?>>Poli Bedah Plastik</option>
                                                <option value="Poli Bedah"<?php if('Poli Bedah'==$datas->unit): ?> selected <?php endif; ?>>Poli Bedah</option>
                                                <option value="Poli THT"<?php if('Poli THT'==$datas->unit): ?> selected <?php endif; ?>>Poli THT</option>
                                                <option value="Poli Kandungan"<?php if('Poli Kandungan'==$datas->unit): ?> selected <?php endif; ?>>Poli Kandungan</option>
                                                <option value="Poli anak"<?php if('Poli anak'==$datas->unit): ?> selected <?php endif; ?>>Poli anak</option>
                                                <option value="Poli Dalam"<?php if('Poli Dalam'==$datas->unit): ?> selected <?php endif; ?>>Poli Dalam</option>
                                                <option value="Nifas"<?php if('Nifas'==$datas->unit): ?> selected <?php endif; ?>>Nifas</option>
                                                <option value="Kamar Bersalin"<?php if('Kamar Bersalin'==$datas->unit): ?> selected <?php endif; ?>>Kamar Bersalin</option>
                                                <option value="Kantor PT"<?php if('Kantor PT'==$datas->unit): ?> selected <?php endif; ?>>Kantor PT</option>
                                                <option value="Rehabilitasi Medik"<?php if('Rehabilitasi Medik'==$datas->unit): ?> selected <?php endif; ?>>Rehabilitasi Medik</option>
                                                <option value="Pos Parkir"<?php if('Pos Parkir'==$datas->unit): ?> selected <?php endif; ?>>Pos Parkir</option>
                                                <option value="Security"<?php if('Security'==$datas->unit): ?> selected <?php endif; ?>>Security</option>
                                                <option value="Gizi"<?php if('Gizi'==$datas->unit): ?> selected <?php endif; ?>>Gizi</option>
                                                <option value="Management"<?php if('Management'==$datas->unit): ?> selected <?php endif; ?>>Management</option>
                                                <option value="Kamar Operasi (OK)"<?php if('Kamar Operasi (OK)'==$datas->unit): ?> selected <?php endif; ?>>Kamar Operasi (OK)</option>
                                                <option value="CSSD"<?php if('CSSD'==$datas->unit): ?> selected <?php endif; ?>>CSSD</option>
                                                <option value="Perinatologi"<?php if('Perinatologi'==$datas->unit): ?> selected <?php endif; ?>>Perinatologi</option>
                                                <option value="Rekam Medis"<?php if('Rekam Medis'==$datas->unit): ?> selected <?php endif; ?>>Rekam Medis</option>
                                                <option value="Farmasi"<?php if('Farmasi'==$datas->unit): ?> selected <?php endif; ?>>Farmasi</option>
                                                <option value="Gudang Farmasi"<?php if('Gudang Farmasi'==$datas->unit): ?> selected <?php endif; ?>>Gudang Farmasi</option>
                                                <option value="Laboratorium"<?php if('Laboratorium'==$datas->unit): ?> selected <?php endif; ?>>Laboratorium</option>
                                                <option value="Radiologi"<?php if('Radiologi'==$datas->unit): ?> selected <?php endif; ?>>Radiologi</option>
                                                <option value="ICU"<?php if('ICU'==$datas->unit): ?> selected <?php endif; ?>>ICU</option>
                                                <option value="TPP RAJAL"<?php if('TPP RAJAL'==$datas->unit): ?> selected <?php endif; ?>>TPP RAJAL</option>
                                                <option value="TPP RANAP"<?php if('PP RANAP'==$datas->unit): ?> selected <?php endif; ?>>TPP RANAP</option>
                                                <option value="Tempat Baru|Ikut keterangan kerusakan"<?php if('Tempat Baru|Ikut keterangan kerusakan'==$datas->unit): ?> selected <?php endif; ?>>Tempat Baru-ikut keterangan</option>
                                            </select>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="jenis" class="col-sm-2 col-form-label">jenis</label>
                                    <div class="col-sm-10">
                                        <div class="col-sm-10">
                                            <div class="form-check form-check-inline">
                                            <input class="form-check-input" name="jenis" type="checkbox" id="inlineCheckbox1" value="Software" <?php if('Software'==$datas->jenis): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="inlineCheckbox1">Software</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                            <input class="form-check-input" name="jenis" type="checkbox" id="inlineCheckbox2" value="Hardware" <?php if('Hardware'==$datas->jenis): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="inlineCheckbox2">Hardware</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                            <input class="form-check-input" name="jenis" type="checkbox" id="inlineCheckbox3" value="Jaringan" <?php if('Jaringan'==$datas->jenis): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="inlineCheckbox3">Jaringan</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="Keluhan" class="col-sm-2 col-form-label">Keluhan</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control"
                                            name='Keluhan'value="<?php echo e($datas->Keluhan); ?>" id="Keluhan">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="jam_laporan" class="col-sm-2 col-form-label">jam laporan</label>
                                    <div class="col-sm-10">
                                        <input type="time" class="form-control" 
                                            name="jam_laporan" value="<?php echo e($datas->jam_laporan); ?>" id="jam_laporan">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="jam_selesai" class="col-sm-2 col-form-label">jam respon</label>
                                    <div class="col-sm-10">
                                        <input type="time" class="form-control"
                                            name='jam_selesai'value="<?php echo e($datas->jam_selesai); ?>" id="jam_selesai">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="jenis_keluhan" class="col-sm-2 col-form-label">jeniskeluhan</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control"
                                            name='jenis_keluhan'value="<?php echo e($datas->jenis_keluhan); ?>" id="jenis_keluhan">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="keterangan" class="col-sm-2 col-form-label">keterangan</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control"
                                            name='keterangan'value="<?php echo e($datas->keterangan); ?>" id="keterangan">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="merk" class="col-sm-2 col-form-label"></label>
                                    <div class="col-sm-10"><button type="submit" class="btn btn-primary"
                                            name="submit">SIMPAN</button></div>
                                </div>
                            </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('laporan.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Project\data\rs\resources\views/laporan/laporan-it/edit.blade.php ENDPATH**/ ?>