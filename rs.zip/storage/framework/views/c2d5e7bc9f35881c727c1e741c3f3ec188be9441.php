
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4 mt-4">
  <h1 class="h2">Edit Laporan</h1>

</div>
  <div class="container mt-5 mb-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card border-0 shadow rounded">
                <div class="card-body">
                    <form action="/laporan-service/ <?php echo e($datas->id); ?>" method='post'>
                        <?php echo csrf_field(); ?>
                    
                       <?php echo method_field('PUT'); ?>
                        <div class="my-3 p-3 bg-body rounded shadow-sm">
                            <div class="mb-3 row">
                                <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control" name='tanggal' value="<?php echo e($datas->tanggal); ?>" id="tanggal">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="font-weight-bold">Nama Ruangan</label>
                                            <select class="form-select" name="id_ruangan">
                                                <?php $__currentLoopData = $data_ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php if($item->id==$datas->id_ruangan): ?> selected <?php endif; ?>><?php echo e($item->nama_ruangan); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </select>
                            </div>
                            <div class="mb-3 row">
                                <label class="font-weight-bold">Merk</label>
                                            <select class="form-select" name="id_merk">
                                                <?php $__currentLoopData = $data_merk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php if($item->id==$datas->id_merk): ?> selected <?php endif; ?>><?php echo e($item->nama_merk); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </select>
                            </div>
                            <div class="mb-3 row">
                                <label for="status" class="col-sm-2 col-form-label">status</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name='status'value="<?php echo e($datas->status); ?>" id="status">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="keterangan" class="col-sm-2 col-form-label">keterangan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name='keterangan'value="<?php echo e($datas->keterangan); ?>" id="keterangan">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="merk" class="col-sm-2 col-form-label"></label>
                                <div class="col-sm-10"><button type="submit" class="btn btn-primary" name="submit">SIMPAN</button></div>
                            </div>
                          </form>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('laporan.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Project\data\rs\resources\views/laporan/laporan-service/edit.blade.php ENDPATH**/ ?>