

<?php $__env->startSection('container'); ?>
<h1>IISIII</h1>

<main class="container">
    <!-- START FORM -->
    <form action='' method='post'>
     <div class="my-3 p-3 bg-body rounded shadow-sm">
         <div class="mb-3 row">
             <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
             <div class="col-sm-10">
                 <input type="number" class="form-control" name='tanggal' id="tanggal">
             </div>
         </div>
         <div class="mb-3 row">
             <label for="ruangan" class="col-sm-2 col-form-label">ruangan</label>
             <div class="col-sm-10">
                 <input type="text" class="form-control" name='ruangan' id="ruangan">
             </div>
         </div>
         <div class="mb-3 row">
             <label for="merk" class="col-sm-2 col-form-label">merk</label>
             <div class="col-sm-10">
                 <input type="text" class="form-control" name='merk' id="merk">
             </div>
         </div>
         <div class="mb-3 row">
             <label for="status" class="col-sm-2 col-form-label">status</label>
             <div class="col-sm-10">
                 <input type="text" class="form-control" name='status' id="status">
             </div>
         </div>
         <div class="mb-3 row">
             <label for="keterangan" class="col-sm-2 col-form-label">keterangan</label>
             <div class="col-sm-10">
                 <input type="text" class="form-control" name='keterangan' id="keterangan">
             </div>
         </div>
         <div class="mb-3 row">
             <label for="merk" class="col-sm-2 col-form-label"></label>
             <div class="col-sm-10"><button type="submit" class="btn btn-primary" name="submit">SIMPAN</button></div>
         </div>
       </form>
     </div>
     <!-- AKHIR FORM -->
     
     <!-- START DATA -->
     <div class="my-3 p-3 bg-body rounded shadow-sm">
             <!-- FORM PENCARIAN -->
             <div class="pb-3">
               <form class="d-flex" action="" method="get">
                   <input class="form-control me-1" type="search" name="katakunci" value="<?php echo e(Request::get('katakunci')); ?>" placeholder="Masukkan kata kunci" aria-label="Search">
                   <button class="btn btn-secondary" type="submit">Cari</button>
               </form>
             </div>
             
             <!-- TOMBOL TAMBAH DATA -->
             <div class="pb-3">
               <a href='' class="btn btn-primary">+ Tambah Data</a>
             </div>
       
             <table class="table table-striped">
                 <thead>
                     <tr>
                         <th class="col-md-1">No</th>
                         <th class="col-md-2">tanggal</th>
                         <th class="col-md-2">ruangan</th>
                         <th class="col-md-2">merk</th>
                         <th class="col-md-2">status</th>
                         <th class="col-md-5">keterangan</th>
                         <th class="col-md-2">Aksi</th>
                     </tr>
                 </thead>
                 <tbody>
                     <tr>
                         <td>1</td>
                         <td>1001</td>
                         <td>Ani</td>
                         <td>Ilmu Komputer</td>
                         <td>Ilmu Komputer</td>
                         <td>Ilmu Komputer</td>
                         <td>
                             <a href='' class="btn btn-warning btn-sm">Edit</a>
                             <a href='' class="btn btn-danger btn-sm">Del</a>
                         </td>
                     </tr>
                 </tbody>
             </table>
            
       </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Project\data\rs\resources\views/laporan/laporan-service.blade.php ENDPATH**/ ?>