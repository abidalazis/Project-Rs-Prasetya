

<?php $__env->startSection('container'); ?>
<!-- START FORM -->
<form action="/tambah-merk/ <?php echo e($merk->id); ?>" method='post'>
    <?php echo csrf_field(); ?>

   <?php echo method_field('PUT'); ?>
    <div class="my-3 p-3 bg-body rounded shadow-sm">
        
        <div class="mb-3 row">
            <label for="nama_merk" class="col-sm-2 col-form-label">Nama Merk</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='nama_merk'value="<?php echo e($merk->nama_merk); ?>" id="nama_merk">
            </div>
        </div>
        <div class="mb-3 row">
            <label class="font-weight-bold">Nama Ruangan</label>
                        <select class="form-select" name="id_ruangan">
                            <?php $__currentLoopData = $data_ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php if($item->id==$merk->id_ruangan): ?> selected <?php endif; ?>><?php echo e($item->nama_ruangan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
        </div>
        <div class="mb-3 row">
            <label for="jenis" class="col-sm-2 col-form-label">Jenis</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='jenis'value="<?php echo e($merk->jenis); ?>" id="jenis">
            </div>
        </div>
        <div class="mb-3 row">
            <label for="keterangan" class="col-sm-2 col-form-label">keterangan</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name='keterangan'value="<?php echo e($merk->keterangan); ?>" id="keterangan">
            </div>
        </div>
        <div class="mb-3 row">
            <label for="merk" class="col-sm-2 col-form-label"></label>
            <div class="col-sm-10"><button type="submit" class="btn btn-primary" name="submit">SIMPAN</button></div>
        </div>
      </form>
    </div>
    <!-- AKHIR FORM -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Project\data\rs\resources\views/merk/edit.blade.php ENDPATH**/ ?>