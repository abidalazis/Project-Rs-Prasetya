
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('laporan.layouts.pesan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Laporan Service</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
        <li class="breadcrumb-item active">Laporan Service</li>
    </ol>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            DataTable Example
        </div>
        <div class="card-body">
            <a href="<?php echo e(route('laporan-service.create')); ?>" class="btn btn-primary">Tambah</a>
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Ruangan</th>
                        <th>Merk</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->tanggal); ?></td>
                        <td><?php echo e(optional($item->ruangan)->nama_ruangan); ?></td>
                        <td><?php echo e(optional($item->merk)->nama_merk); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td><?php echo e($item->keterangan); ?></td>
                        <td>
                            <a href="/laporan-service/ <?php echo e($item->id); ?>/edit" class="btn btn-warning btn-sm">Edit</a>
                            <form onsubmit="return confirm('YAKIN AKAN MENGHAPUS?')" class="d-inline" action="/laporan-service/ <?php echo e($item->id); ?>"
                                method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            <button type="submit" name="submit" class="btn btn-danger btn-sm">Del</button>
                            </form>
                        </td>
                    </tr>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
            </table>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('laporan.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Project\data\rs\resources\views/laporan/laporan-service/index.blade.php ENDPATH**/ ?>