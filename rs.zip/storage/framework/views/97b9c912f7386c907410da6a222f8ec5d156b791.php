

<?php $__env->startSection('container'); ?>
<h1>IISIII</h1>

<main class="container">
    
     <!-- START DATA -->
     <div class="my-3 p-3 bg-body rounded shadow-sm">
             <!-- FORM PENCARIAN -->
             <div class="pb-3">
               <form class="d-flex" action="/tambah-ruangan" method="get">
                   <input class="form-control me-1" type="search" name="katakunci" value="<?php echo e(Request::get('katakunci')); ?>" placeholder="Masukkan kata kunci" aria-label="Search">
                   <button class="btn btn-secondary" type="submit">Cari</button>
               </form>
             </div>
             
             <!-- TOMBOL TAMBAH DATA -->
             <div class="pb-3">
               <a href='/tambah-ruangan/create' class="btn btn-primary">+ Tambah Data</a>
             </div>
       
             <table class="table table-striped">
                 <thead>
                     <tr>
                         <th class="col-md-1">No</th>
                         <th class="col-md-2">Nama Ruangan</th>
                         <th class="col-md-2">Keterangan</th>
                         <th class="col-md-4">Aksi</th>
                     </tr>
                 </thead>
                 <tbody>
                    
                    <?php $__currentLoopData = $data_ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->nama_ruangan); ?></td>
                        <td><?php echo e($item->keterangan); ?></td>
                        <td>
                            <a href="/tambah-ruangan/ <?php echo e($item->id); ?>/edit" class="btn btn-warning btn-sm">Edit</a>
                            <form onsubmit="return confirm('YAKIN AKAN MENGHAPUS?')" class="d-inline" action="/tambah-ruangan/ <?php echo e($item->id); ?>"
                                method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            <button type="submit" name="submit" class="btn btn-danger btn-sm">Del</button>
                            </form>
                        </td>
                    </tr>       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
             </table>
       </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Project\data\rs\resources\views/ruangan/index.blade.php ENDPATH**/ ?>