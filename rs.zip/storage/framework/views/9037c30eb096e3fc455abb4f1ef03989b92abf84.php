
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="h2">Edit Ruangan</h1>
    
  </div>
  <div class="container mt-5 mb-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card border-0 shadow rounded">
                <div class="card-body">
                    <form action="/tambah-ruangan/ <?php echo e($datas->id); ?>" method='post'>
                        <?php echo csrf_field(); ?>
                    
                       <?php echo method_field('PUT'); ?>
                        <div class="my-3 p-3 bg-body rounded shadow-sm">
                            
                            <div class="mb-3 row">
                                <label for="nama_ruangan" class="col-sm-2 col-form-label">Nama Ruangan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name='nama_ruangan'value="<?php echo e($datas->nama_ruangan); ?>" id="nama_ruangan">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="keterangan" class="col-sm-2 col-form-label">keterangan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name='keterangan'value="<?php echo e($datas->keterangan); ?>" id="keterangan">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="merk" class="col-sm-2 col-form-label"></label>
                                <div class="col-sm-10"><button type="submit" class="btn btn-primary" name="submit">SIMPAN</button></div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Project\data\rs\resources\views/dashboard/ruangan/edit.blade.php ENDPATH**/ ?>